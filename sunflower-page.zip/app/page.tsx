import { SunflowerBouquet } from "@/components/sunflower-bouquet"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-orange-50 via-yellow-50 to-amber-50 flex flex-col items-center justify-center p-8">
      <div className="max-w-2xl mx-auto text-center space-y-12">
        {/* Sunflower Bouquet */}
        <div className="animate-fade-in">
          <SunflowerBouquet />
        </div>

        {/* Romantic Message */}
        <div className="space-y-6 animate-fade-in-up">
          <h1 className="font-playfair text-5xl md:text-6xl font-bold text-primary leading-tight text-balance">
            Para mi niña bonita
          </h1>

          <div className="w-24 h-1 bg-gradient-to-r from-primary to-secondary mx-auto rounded-full"></div>

          <p className="font-open-sans text-lg md:text-xl text-muted-foreground max-w-md mx-auto leading-relaxed">
            Como estos girasoles que siempre buscan la luz, mi corazón siempre te busca a ti
          </p>
        </div>

        {/* Decorative hearts */}
        <div className="flex justify-center space-x-4 text-2xl animate-pulse">
          <span className="text-primary">💛</span>
          <span className="text-secondary">🌻</span>
          <span className="text-primary">💛</span>
        </div>
      </div>

      {/* Floating petals animation */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {Array.from({ length: 6 }, (_, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              animationDelay: `${i * 2}s`,
              animationDuration: `${8 + Math.random() * 4}s`,
            }}
          >
            <div className="w-3 h-3 bg-primary rounded-full opacity-30"></div>
          </div>
        ))}
      </div>
    </main>
  )
}
