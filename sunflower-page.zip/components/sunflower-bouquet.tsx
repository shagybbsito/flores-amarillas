export function SunflowerBouquet() {
  return (
    <div className="flex justify-center items-center">
      <svg width="300" height="400" viewBox="0 0 300 400" className="drop-shadow-lg" xmlns="http://www.w3.org/2000/svg">
        {/* Stems */}
        <g stroke="#22c55e" strokeWidth="4" fill="none">
          <path d="M150 380 L150 250" strokeLinecap="round" />
          <path d="M120 370 L120 280" strokeLinecap="round" />
          <path d="M180 375 L180 270" strokeLinecap="round" />
          <path d="M100 360 L100 300" strokeLinecap="round" />
          <path d="M200 365 L200 290" strokeLinecap="round" />
        </g>

        {/* Leaves */}
        <g fill="#16a34a">
          <ellipse cx="135" cy="320" rx="8" ry="15" transform="rotate(-30 135 320)" />
          <ellipse cx="165" cy="310" rx="8" ry="15" transform="rotate(30 165 310)" />
          <ellipse cx="105" cy="340" rx="7" ry="12" transform="rotate(-45 105 340)" />
          <ellipse cx="195" cy="330" rx="7" ry="12" transform="rotate(45 195 330)" />
          <ellipse cx="85" cy="335" rx="6" ry="10" transform="rotate(-20 85 335)" />
          <ellipse cx="215" cy="325" rx="6" ry="10" transform="rotate(20 215 325)" />
        </g>

        {/* Sunflower 1 - Center */}
        <g transform="translate(150, 200)">
          {/* Petals */}
          <g fill="#fbbf24">
            {Array.from({ length: 16 }, (_, i) => {
              const angle = (i * 22.5 * Math.PI) / 180
              const x = Math.cos(angle) * 35
              const y = Math.sin(angle) * 35
              return <ellipse key={i} cx={x} cy={y} rx="8" ry="20" transform={`rotate(${i * 22.5 + 90} ${x} ${y})`} />
            })}
          </g>
          {/* Center */}
          <circle cx="0" cy="0" r="18" fill="#d97706" />
          <circle cx="0" cy="0" r="12" fill="#92400e" />
        </g>

        {/* Sunflower 2 - Left */}
        <g transform="translate(120, 230)">
          <g fill="#fbbf24">
            {Array.from({ length: 14 }, (_, i) => {
              const angle = (i * 25.7 * Math.PI) / 180
              const x = Math.cos(angle) * 28
              const y = Math.sin(angle) * 28
              return <ellipse key={i} cx={x} cy={y} rx="6" ry="16" transform={`rotate(${i * 25.7 + 90} ${x} ${y})`} />
            })}
          </g>
          <circle cx="0" cy="0" r="15" fill="#d97706" />
          <circle cx="0" cy="0" r="10" fill="#92400e" />
        </g>

        {/* Sunflower 3 - Right */}
        <g transform="translate(180, 220)">
          <g fill="#fbbf24">
            {Array.from({ length: 14 }, (_, i) => {
              const angle = (i * 25.7 * Math.PI) / 180
              const x = Math.cos(angle) * 30
              const y = Math.sin(angle) * 30
              return <ellipse key={i} cx={x} cy={y} rx="7" ry="17" transform={`rotate(${i * 25.7 + 90} ${x} ${y})`} />
            })}
          </g>
          <circle cx="0" cy="0" r="16" fill="#d97706" />
          <circle cx="0" cy="0" r="11" fill="#92400e" />
        </g>

        {/* Sunflower 4 - Far Left */}
        <g transform="translate(100, 260)">
          <g fill="#fbbf24">
            {Array.from({ length: 12 }, (_, i) => {
              const angle = (i * 30 * Math.PI) / 180
              const x = Math.cos(angle) * 25
              const y = Math.sin(angle) * 25
              return <ellipse key={i} cx={x} cy={y} rx="5" ry="14" transform={`rotate(${i * 30 + 90} ${x} ${y})`} />
            })}
          </g>
          <circle cx="0" cy="0" r="13" fill="#d97706" />
          <circle cx="0" cy="0" r="9" fill="#92400e" />
        </g>

        {/* Sunflower 5 - Far Right */}
        <g transform="translate(200, 250)">
          <g fill="#fbbf24">
            {Array.from({ length: 12 }, (_, i) => {
              const angle = (i * 30 * Math.PI) / 180
              const x = Math.cos(angle) * 26
              const y = Math.sin(angle) * 26
              return <ellipse key={i} cx={x} cy={y} rx="5" ry="15" transform={`rotate(${i * 30 + 90} ${x} ${y})`} />
            })}
          </g>
          <circle cx="0" cy="0" r="14" fill="#d97706" />
          <circle cx="0" cy="0" r="9" fill="#92400e" />
        </g>

        {/* Decorative ribbon */}
        <g fill="#d97706" opacity="0.8">
          <path d="M80 350 Q150 340 220 350 Q150 360 80 350" />
          <text x="150" y="355" textAnchor="middle" fill="white" fontSize="12" fontFamily="serif">
            💝
          </text>
        </g>
      </svg>
    </div>
  )
}
